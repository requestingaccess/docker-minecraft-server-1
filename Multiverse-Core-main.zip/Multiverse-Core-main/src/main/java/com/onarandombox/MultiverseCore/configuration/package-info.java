/**
 * This package contains the Multiverse-configuration.
 */
package com.onarandombox.MultiverseCore.configuration;
