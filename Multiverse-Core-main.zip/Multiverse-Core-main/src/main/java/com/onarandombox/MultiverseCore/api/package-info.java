/**
 * The Multiverse-API, containing lots of interfaces that can be quite useful for other
 * plugins when interacting with Multiverse.
 */
package com.onarandombox.MultiverseCore.api;
