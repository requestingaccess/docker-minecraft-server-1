/**
 * This package contains all destination-types.
 */
package com.onarandombox.MultiverseCore.destination;
