/**
 * This package contains all enums.
 */
package com.onarandombox.MultiverseCore.enums;
