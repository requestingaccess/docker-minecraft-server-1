/**
 * This package contains all exceptions.
 */
package com.onarandombox.MultiverseCore.exceptions;
