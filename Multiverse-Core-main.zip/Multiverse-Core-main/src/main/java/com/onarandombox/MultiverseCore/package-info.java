/**
 * The "master"-package, containing everything related to Multiverse-Core.
 */
package com.onarandombox.MultiverseCore;
