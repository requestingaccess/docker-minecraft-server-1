/**
 * This package contains all listeners.
 */
package com.onarandombox.MultiverseCore.listeners;
