/**
 * This package contains all events.
 */
package com.onarandombox.MultiverseCore.event;
